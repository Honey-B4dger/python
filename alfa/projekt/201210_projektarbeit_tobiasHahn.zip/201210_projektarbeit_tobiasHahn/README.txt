grids are stored in grids/

data is written in data/

solutions for verify.py are stored in solutions/

start sudoku_run.py to launch command line interface

bonus file: project_stats.py